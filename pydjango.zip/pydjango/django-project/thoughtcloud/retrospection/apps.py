from django.apps import AppConfig


class RetrospectionConfig(AppConfig):
    name = 'retrospection'
